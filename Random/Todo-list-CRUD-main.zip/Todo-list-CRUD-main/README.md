# TODO-LİST

This is an TODO-LİST website. 


## TECHNOLOGIES/PACKAGES/TEMPLATE I USE
* Javascript
* Flex
* Create , delete and update buttons (CRUD)
* Fontawesome



##  <a href="https://mellow-dolphin-911266.netlify.app/" target="_blank" alt="demo link">Demo Link: CLİCK ME </a>

## Screenshots:
![image](https://user-images.githubusercontent.com/72821281/208255503-9b2cb3c2-3dfe-4dda-aa2e-b2c9410e9486.png)





